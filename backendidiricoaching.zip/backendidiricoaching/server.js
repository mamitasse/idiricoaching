//IDIRICOACHING/backendendidiricoaching/server.js

const express = require('express');
const mongoose = require('mongoose');
const helmet = require('helmet');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Vérification des variables d'environnement critiques
if (!process.env.MONGO_URI) {
  console.error('⚠️  La variable d\'environnement MONGO_URI est manquante.');
  process.exit(1);
}

// Connexion à MongoDB
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ Connecté à MongoDB'))
  .catch(err => {
    console.error('❌ Erreur MongoDB :', err);
    process.exit(1);
  });


// Middleware globaux
app.use(express.json());
app.use(helmet());
app.use(cors({
  origin: 'http://localhost:3000', // URL du frontend
  credentials: true, // Permet l'envoi des cookies (si nécessaire)
}));

// Importation des routes
const userRoutes = require('./routes/userRoutes');

const coachRoutes = require('./routes/coachRoutes');
const slotRoutes = require('./routes/slotRoutes');
const reservationRoutes = require('./routes/reservationRoutes');
const emailRoutes = require('./routes/emailRoutes');

// Utilisation des routes
app.use('/api/users', userRoutes);
app.use('/api/coaches', coachRoutes);
app.use('/api/slots', slotRoutes);
app.use('/api/reservations', reservationRoutes);
app.use('/api/emails', emailRoutes);

// Gestion des erreurs 404 pour les routes non trouvées
app.use((req, res, next) => {
  res.status(404).json({ error: 'Ressource non trouvée.' });
});

// Middleware global pour la gestion des erreurs
app.use((err, req, res, next) => {
  console.error('Erreur détectée :', err.stack);
  res.status(err.status || 500).json({
    error: err.message || 'Erreur serveur.',
  });
});

// Démarrage du serveur
app.listen(PORT, () => {
  console.log(`🚀 Serveur démarré sur le port ${PORT}`);
});
