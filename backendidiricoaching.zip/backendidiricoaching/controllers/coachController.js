//IDIRICOACHING/backendendidiricoaching/controllers/coachController.js

const User = require('../models/user');
const Slot = require('../models/slot');

exports.getAvailableSlots = async (req, res) => {
  try {
    const slots = await Slot.find({ coachId: req.params.coachId, isBooked: false });
    res.status(200).json(slots);
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de la récupération des créneaux' });
  }
};

exports.reserveSlot = async (req, res) => {
  try {
    const { slotId } = req.body;
    const slot = await Slot.findById(slotId);
    if (!slot || slot.isBooked) {
      return res.status(400).json({ message: 'Créneau non disponible.' });
    }
    slot.isBooked = true;
    slot.adherent = req.user.id;
    await slot.save();
    res.status(200).json({ message: 'Créneau réservé avec succès.', slot });
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de la réservation du créneau' });
  }
};

exports.cancelReservation = async (req, res) => {
  try {
    const slot = await Slot.findById(req.params.slotId);
    if (!slot || !slot.isBooked) {
      return res.status(400).json({ message: 'Ce créneau n\'est pas réservé.' });
    }
    slot.isBooked = false;
    slot.adherent = null;
    await slot.save();
    res.status(200).json({ message: 'Réservation annulée avec succès.', slot });
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de l\'annulation de la réservation.' });
  }
};

exports.getReservedSlotsByAdherent = async (req, res) => {
  try {
    const slots = await Slot.find({ adherent: req.params.adherentId, isBooked: true });
    res.status(200).json(slots);
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de la récupération des créneaux réservés.' });
  }
};
