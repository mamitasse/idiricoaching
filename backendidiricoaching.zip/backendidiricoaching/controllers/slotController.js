const Slot = require('../models/slot');

exports.generateDefaultSlots = async (req, res) => {
  const { date } = req.body;

  try {
    const existingSlots = await Slot.find({ date, coach: req.user._id });
    if (existingSlots.length > 0) return res.status(400).json({ error: 'Des créneaux existent déjà.' });

    const slots = [];
    for (let hour = 8; hour < 21; hour++) {
      slots.push({ coach: req.user._id, date, startTime: `${hour}:00`, endTime: `${hour + 1}:00`, status: 'available' });
    }

    await Slot.insertMany(slots);
    res.status(201).json({ message: 'Créneaux générés avec succès.' });
  } catch (error) {
    res.status(500).json({ error: 'Erreur serveur lors de la génération des créneaux.' });
  }
};

exports.getSlots = async (req, res) => {
  const { date } = req.query;

  try {
    const slots = await Slot.find({ coach: req.user._id, date });
    res.status(200).json(slots);
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de la récupération des créneaux.' });
  }
};

exports.deleteDaySlots = async (req, res) => {
  const { date } = req.body;

  try {
    await Slot.deleteMany({ coach: req.user._id, date });
    res.status(200).json({ message: 'Créneaux supprimés.' });
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de la suppression des créneaux.' });
  }
};

exports.deleteSelectedSlots = async (req, res) => {
  const { slotIds } = req.body;

  try {
    await Slot.deleteMany({ _id: { $in: slotIds }, coach: req.user._id });
    res.status(200).json({ message: 'Créneaux sélectionnés supprimés.' });
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de la suppression des créneaux sélectionnés.' });
  }
};
