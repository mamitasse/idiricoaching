const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { authMiddleware, roleMiddleware } = require('../middleware/authMiddleware');
const { loginUser } = require('../controllers/authController');
const User = require('../models/user');

const router = express.Router();

/**
 * Route pour l'inscription des adhérents.
 */
router.post('/adherent-register', async (req, res) => {
  const {
    firstName,
    lastName,
    email,
    password,
    gender,
    age,
    coachId,
    phone,
    address,
  } = req.body;

  if (!firstName || !lastName || !email || !password || !gender || !age || !coachId || !phone || !address) {
    return res.status(400).json({ message: 'Tous les champs sont obligatoires.' });
  }

  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Cet email est déjà utilisé.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
      firstName,
      lastName,
      email,
      password: hashedPassword,
      role: 'adherent',
      gender,
      age,
      coachId,
      phone,
      address,
    });

    await newUser.save();
    res.status(201).json({ message: 'Utilisateur enregistré avec succès.' });
  } catch (error) {
    console.error('Erreur lors de l\'inscription :', error);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
});

/**
 * Route pour la connexion des utilisateurs.
 */
router.post('/login', loginUser);

/**
 * Route pour récupérer l'utilisateur connecté.
 */
router.get('/me', authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId)
      .populate('coachId', 'firstName lastName') // Récupère le coach associé
      .select('-password'); // Exclut le mot de passe
    if (!user) {
      return res.status(404).json({ message: 'Utilisateur non trouvé.' });
    }

    res.json(user);
  } catch (error) {
    console.error('Erreur lors de la récupération de l\'utilisateur :', error);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
});


/**
 * Route pour récupérer tous les adhérents (accessible uniquement aux coaches).
 */
router.get('/adherents', authMiddleware, roleMiddleware(['coach']), async (req, res) => {
  try {
    const adherents = await User.find({ role: 'adherent' }).select('firstName lastName email coachId');
    res.json(adherents);
  } catch (error) {
    console.error('Erreur lors de la récupération des adhérents :', error);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
});

/**
 * Route pour récupérer tous les coaches (accessible uniquement aux adhérents).
 */
router.get('/coaches', authMiddleware, roleMiddleware(['adherent']), async (req, res) => {
  try {
    const coaches = await User.find({ role: 'coach' }).select('firstName lastName email');
    res.json(coaches);
  } catch (error) {
    console.error('Erreur lors de la récupération des coaches :', error);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
});

module.exports = router;
