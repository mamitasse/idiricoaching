//IDIRICOACHING/backendendidiricoaching/routes/coachRoutes.js

const express = require('express');
const router = express.Router();
const { authMiddleware, roleMiddleware } = require('../middleware/authMiddleware');
const Slot = require('../models/slot');

// Route pour récupérer les créneaux disponibles d'un coach spécifique
router.get('/:coachId/slots', authMiddleware, async (req, res) => {
    const { coachId } = req.params;
    const { date } = req.query; // Option pour filtrer par date
  
    try {
      const filter = { coach: coachId };
      if (date) {
        const startOfDay = new Date(date);
        const endOfDay = new Date(date);
        endOfDay.setHours(23, 59, 59, 999);
  
        filter.startTime = { $gte: startOfDay, $lte: endOfDay };
      }
  
      const slots = await Slot.find(filter).populate('bookedBy', 'firstName lastName email');
      res.status(200).json(slots);
    } catch (error) {
      console.error('Erreur lors de la récupération des créneaux :', error);
      res.status(500).json({ error: 'Erreur serveur lors de la récupération des créneaux.' });
    }
  });
  

// Route pour ajouter un créneau
router.post('/slots', authMiddleware, roleMiddleware(['coach']), async (req, res) => {
    const { coachId, date } = req.body;

    if (!coachId || !date) {
        return res.status(400).json({ error: 'Coach ID et date sont requis.' });
    }

    try {
        const slot = new Slot({
            coach: coachId,
            date,
            isBooked: false,
        });
        await slot.save();

        res.status(201).json(slot);
    } catch (error) {
        console.error('Erreur lors de la création du créneau:', error);
        res.status(500).json({ error: 'Erreur serveur lors de la création du créneau.' });
    }
});

// Route pour supprimer un créneau
router.delete('/slots/:slotId', authMiddleware, roleMiddleware(['coach']), async (req, res) => {
    try {
        const { slotId } = req.params;
        await Slot.findByIdAndDelete(slotId);
        res.status(200).json({ message: 'Créneau supprimé avec succès.' });
    } catch (error) {
        console.error('Erreur lors de la suppression du créneau:', error);
        res.status(500).json({ error: 'Erreur serveur lors de la suppression du créneau.' });
    }
});

module.exports = router;
