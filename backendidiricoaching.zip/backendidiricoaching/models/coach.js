//IDIRICOACHING/backendendidiricoaching/models/coach.js

const mongoose = require('mongoose');

// Schéma des créneaux horaires
const timeSlotSchema = new mongoose.Schema({
  time: { type: String, required: true },  // Heure du créneau (par exemple, "09:00")
  isReserved: { type: Boolean, default: false },  // Statut du créneau
  reservedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },  // ID de l'utilisateur ayant réservé
});

// Schéma principal du coach
const coachSchema = new mongoose.Schema({
  name: { type: String, required: true },  // Nom du coach
  availableSlots: [
    {
      date: { type: String, required: true },  // Date de disponibilité (par exemple, "2024-11-15")
      timeSlots: [timeSlotSchema],  // Liste des créneaux horaires pour cette date
    },
  ],
});

const Coach = mongoose.model('Coach', coachSchema);

module.exports = Coach;
