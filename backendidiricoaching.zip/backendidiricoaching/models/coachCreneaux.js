const mongoose = require('mongoose');

const timeSlotSchema = new mongoose.Schema({
  startTime: {
    type: String,
    required: true,  // Ex: "10:00"
  },
  endTime: {
    type: String,
    required: true,  // Ex: "11:00"
  },
});

const creneauCoachSchema = new mongoose.Schema({
  coach: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',  // On suppose que le modèle User inclut les coachs
    required: true,
  },
  date: {
    type: Date,
    required: true,
  },
  timeSlots: [timeSlotSchema],  // Tableau de créneaux horaires
});

const CreneauCoach = mongoose.model('CreneauCoach', creneauCoachSchema);

module.exports = CreneauCoach;
